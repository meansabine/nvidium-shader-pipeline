#version 460 core
#extension GL_ARB_shading_language_include : enable
#pragma optionNV(unroll all)
#define UNROLL_LOOP
#extension GL_NV_gpu_shader5 : require
#extension GL_NV_bindless_texture : require
#extension GL_NV_shader_buffer_load : require
#extension GL_NV_fragment_shader_barycentric : require

#import <nvidium:occlusion/scene.glsl>
#import <nvidium:terrain/vertex_format.glsl>

#include "../common/scene_uniforms.glsl"
#include "../common/options.glsl"
#include "../common/materials.glsl"
#include "../common/pbr_brdf.glsl"
#include "../common/shadows.glsl"
#include "../common/atmosphere.glsl"
#include "../common/post_tonemap.glsl"

layout(binding = 0) uniform sampler2D tex_diffuse;
layout(binding = 1) uniform sampler2D tex_light;
layout(binding = 2) uniform sampler2D tex_normal;
layout(binding = 3) uniform sampler2D tex_specular;
layout(binding = 4) uniform sampler2D tex_scene_color;
layout(binding = 5) uniform sampler2D tex_scene_depth;
layout(binding = 6) uniform sampler2DArray tex_shadow_map;

layout(location = 5) in NvidiumVertexData {
    vec2 v_uv;
    vec3 v_color;
    vec2 v_lightUV;
} nv_in;

layout(location = 0) out vec4 outFragColor;

// Fast 2-Octave Analytical Gerstner Wave Normal (lively organic ripples without multi-octave FBM cost)
vec3 computeFastWaterNormal(vec3 worldPos, vec3 geoNormal) {
    float t = u_Time.x * 1.35 * max(0.3, OPT_WIND_SPEED);
    vec2 p  = worldPos.xz * 0.85;

    // Primary swell + cross chop
    float w1 = sin(p.x * 1.4 + p.y * 0.8 + t);
    float w2 = cos(p.x * 0.9 - p.y * 1.7 + t * 1.25);
    float w3 = sin(p.x * 3.1 - p.y * 2.4 - t * 1.6) * 0.45;

    float dHx = (1.4 * cos(p.x * 1.4 + p.y * 0.8 + t) - 0.9 * sin(p.x * 0.9 - p.y * 1.7 + t * 1.25) + 1.4 * cos(p.x * 3.1 - p.y * 2.4 - t * 1.6));
    float dHz = (0.8 * cos(p.x * 1.4 + p.y * 0.8 + t) + 1.7 * sin(p.x * 0.9 - p.y * 1.7 + t * 1.25) - 1.1 * cos(p.x * 3.1 - p.y * 2.4 - t * 1.6));

    float amp = 0.055 * OPT_WATER_WAVE_HEIGHT;
    return normalize(vec3(-dHx * amp, 1.0, -dHz * amp));
}

// Fast 4-step Screen-Space Reflection with sky fallback
vec3 evaluateWaterReflection(vec3 camRelPos, vec3 R, float skyLight) {
    vec3 skyRefl = evaluatePhysicalSky(R) * smoothstep(0.05, 0.55, skyLight);
    if (u_ShadowParams.z < 0.5) return skyRefl;

    float rayLen = max(length(camRelPos) * 0.35, 4.0);
    for (int i = 1; i <= 4; ++i) {
        vec3 marchPos = camRelPos + R * (rayLen * (float(i) * 0.25));
        vec3 uvDepth  = projectCameraRelativeToUVDepth(marchPos);
        if (any(lessThan(uvDepth.xy, vec2(0.01))) || any(greaterThan(uvDepth.xy, vec2(0.99)))) break;

        float sceneZ = texture(tex_scene_depth, uvDepth.xy).r;
        if (uvDepth.z > sceneZ && uvDepth.z - sceneZ < 0.015) {
            vec2 edgeFade = smoothstep(vec2(0.0), vec2(0.12), uvDepth.xy) * (1.0 - smoothstep(vec2(0.88), vec2(1.0), uvDepth.xy));
            float fade = edgeFade.x * edgeFade.y;
            vec3 ssrColor = srgbToLinear(textureLod(tex_scene_color, uvDepth.xy, 0.0).rgb);
            return mix(skyRefl, ssrColor, fade * 0.85);
        }
    }
    return skyRefl;
}

void main() {
    vec4 diffSample = texture(tex_diffuse, nv_in.v_uv);
    if (diffSample.a < 0.02) discard;

    uint quadId = uint(gl_PrimitiveID) >> 4;
    bool triangle0 = ((uint(gl_PrimitiveID) >> 3) & 1u) == 0u;
    uvec3 triIndices = triangle0 ? uvec3(0u, 1u, 2u) : uvec3(2u, 3u, 0u);

    Vertex V0 = terrainData[(quadId << 2) + triIndices.x];
    Vertex V1 = terrainData[(quadId << 2) + triIndices.y];
    Vertex V2 = terrainData[(quadId << 2) + triIndices.z];

    vec3 pos0 = decodeVertexPosition(V0);
    vec3 pos1 = decodeVertexPosition(V1);
    vec3 pos2 = decodeVertexPosition(V2);

    vec3 edge1 = pos1 - pos0;
    vec3 edge2 = pos2 - pos0;
    vec3 geoNormal = cross(edge1, edge2);
    float geomLen = length(geoNormal);
    geoNormal = (geomLen > 1.0e-6) ? (geoNormal / geomLen) : vec3(0.0, 1.0, 0.0);
    if (!gl_FrontFacing) {
        geoNormal = -geoNormal;
    }

    vec2 screenUV  = gl_FragCoord.xy * u_ScreenSize.zw;
    vec3 camRelPos = reconstructCameraRelativePos(screenUV, gl_FragCoord.z);
    vec3 worldPos  = camRelPos + u_CameraPos.xyz;
    vec3 V         = normalize(-camRelPos);

    // Detect water vs stained glass / ice / translucent blocks via biome water tint or cyan-blue profile
    vec3 tintedSrgb = diffSample.rgb * nv_in.v_color;
    bool isWater = (nv_in.v_color.b > nv_in.v_color.r * 1.15) || (tintedSrgb.b > tintedSrgb.r * 1.25 && abs(geoNormal.y) > 0.7);

    int tonemapOp = int(round(u_PostParams.w));
    float exposure = max(u_PostParams.x, 0.5);
    float userSat  = max(u_PostParams.z, 0.8);

    if (isWater) {
        vec3 N = (geoNormal.y > 0.5) ? computeFastWaterNormal(worldPos, geoNormal) : geoNormal;

        // Screen-space refraction with foreground depth check
        vec2 refractOffset = N.xz * 0.035 / max(length(camRelPos) * 0.15, 1.0);
        vec2 refractUV = clamp(screenUV + refractOffset, vec2(0.002), vec2(0.998));
        float opaqueDepth = texture(tex_scene_depth, refractUV).r;
        if (opaqueDepth < gl_FragCoord.z) {
            refractUV   = screenUV;
            opaqueDepth = texture(tex_scene_depth, screenUV).r;
        }

        vec3 opaqueCamPos = reconstructCameraRelativePos(refractUV, opaqueDepth);
        float waterDepth  = max(0.0, length(opaqueCamPos) - length(camRelPos));

        // Background scene is already tonemapped in mainRenderTarget; convert to linear for physical Beer-Lambert absorption
        vec3 bgLinear = srgbToLinear(textureLod(tex_scene_color, refractUV, 0.0).rgb) / exposure;

        // Underwater procedural caustics on shallow seabeds
        if (OPT_WATER_CAUSTICS > 0.01 && waterDepth < 18.0 && opaqueDepth < 0.9999) {
            vec3 seabedWorld = opaqueCamPos + u_CameraPos.xyz;
            float t = u_Time.x * 1.1;
            float c1 = noise2D(seabedWorld.xz * 1.6 + vec2(t, t * 0.7));
            float c2 = noise2D(seabedWorld.xz * 1.6 - vec2(t * 0.8, -t));
            float caustic = pow(clamp(1.0 - abs(c1 - c2) * 2.2, 0.0, 1.0), 3.0);
            float depthFade = exp(-waterDepth * 0.18) * smoothstep(0.0, 0.6, waterDepth);
            bgLinear *= 1.0 + caustic * OPT_WATER_CAUSTICS * depthFade * u_SkyColor.w * 1.35;
        }

        // Vibrant teal-emerald shallow to deep cobalt Beer-Lambert absorption
        vec3 sigma = vec3(0.42, 0.11, 0.065) / max(0.25, OPT_WATER_CLARITY);
        vec3 transmittance = exp(-sigma * waterDepth);
        vec3 deepWaterColor = vec3(0.012, 0.075, 0.145) * (0.15 + 0.85 * u_SkyColor.w) * nv_in.v_lightUV.y;
        vec3 refracted = bgLinear * transmittance + deepWaterColor * (1.0 - transmittance);

        // Fresnel + Sky/SSR Reflection + Direct Sun Specular Glint
        float NoV = clamp(abs(dot(N, V)), 0.0, 1.0);
        float fresnel = 0.02 + 0.98 * pow(1.0 - NoV, 5.0);
        vec3 R = reflect(-V, N);
        vec3 reflected = evaluateWaterReflection(camRelPos, R, nv_in.v_lightUV.y);

        float shadowVis = evaluateCascadedShadow(tex_shadow_map, camRelPos, geoNormal, gl_FragCoord.xy);
        vec3 H = normalize(V + u_ShadowLightDir.xyz);
        float NoH = clamp(dot(N, H), 0.0, 1.0);
        float sunGlint = D_GGX(NoH, 0.045) * shadowVis * clamp(dot(N, u_ShadowLightDir.xyz), 0.0, 1.0);
        vec3 sunColor = mix(u_MoonColor.rgb * 0.4, u_SunColor.rgb * 1.4, u_SkyColor.w);

        vec3 waterHdr = mix(refracted, reflected, fresnel) + sunColor * sunGlint * 0.35;

        // Subtle shoreline contact foam
        float foam = smoothstep(0.45, 0.02, waterDepth) * 0.45;
        waterHdr = mix(waterHdr, sunColor * 0.65 + vec3(0.25), foam);

        // Tonemap & grade to match opaque background seamlessly
        vec3 graded = applyColorGrading(waterHdr * exposure, userSat);
        vec3 finalSrgb = linearToSrgb(applySelectedTonemap(graded, tonemapOp));
        outFragColor = vec4(finalSrgb, 1.0);
    } else {
        // Dielectric Translucents (Stained Glass, Ice, Slime, Honey, Nether Portal)
        vec3 bgLinear = srgbToLinear(textureLod(tex_scene_color, screenUV, 1.0).rgb) / exposure;
        vec3 glassAlbedo = srgbToLinear(tintedSrgb);
        float NoV = clamp(abs(dot(geoNormal, V)), 0.0, 1.0);
        float fresnel = 0.04 + 0.96 * pow(1.0 - NoV, 5.0);
        vec3 envRefl = evaluateAtmosphericHazeSky(reflect(-V, geoNormal), 0.75) * nv_in.v_lightUV.y;

        vec3 filterTint = mix(vec3(1.0), glassAlbedo * 1.35, diffSample.a);
        vec3 transHdr = bgLinear * filterTint * (1.0 - fresnel * 0.5) + glassAlbedo * diffSample.a * 0.25 + envRefl * fresnel * 0.6;

        vec3 graded = applyColorGrading(transHdr * exposure, userSat);
        vec3 finalSrgb = linearToSrgb(applySelectedTonemap(graded, tonemapOp));
        outFragColor = vec4(finalSrgb, 1.0);
    }
}
