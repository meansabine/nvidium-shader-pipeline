#version 460 core

layout(binding = 0) uniform sampler2D tex_diffuse;

layout(location = 5) in NvidiumVertexData {
    vec2 v_uv;
    vec3 v_color;
    vec2 v_lightUV;
} nv_in;

void main() {
    float alpha = texture(tex_diffuse, nv_in.v_uv).a;
    if (alpha < 0.15) {
        discard;
    }
}
