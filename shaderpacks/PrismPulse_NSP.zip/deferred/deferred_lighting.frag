#version 460 core

#include "../common/scene_uniforms.glsl"
#include "../common/options.glsl"
#include "../common/materials.glsl"
#include "../common/pbr_brdf.glsl"
#include "../common/shadows.glsl"
#include "../common/atmosphere.glsl"

layout(binding = 0) uniform sampler2D gAlbedoRoughness;
layout(binding = 1) uniform sampler2D gNormalMetallic;
layout(binding = 2) uniform sampler2D gLightEmission;
layout(binding = 3) uniform sampler2D gDepth;
layout(binding = 4) uniform sampler2DArray shadowMapArray;

layout(location = 0) in vec2 v_TexCoord;
layout(location = 0) out vec4 outHdrColor;

// Fast 4-Tap Cross Screen-Space Contact AO (with IGN rotation to prevent edge stripes)
float evaluateFastContactAO(vec2 uv, vec3 camRelPos, vec3 N) {
    if (u_ShadowParams.w < 0.5) return 1.0;

    float dist = length(camRelPos);
    if (dist > 128.0) return 1.0;
    vec2 radius = vec2(2.5, 2.5) * u_ScreenSize.zw / clamp(dist * 0.15, 0.5, 3.5);

    float angle = interleavedGradientNoise(gl_FragCoord.xy, 0.0) * 6.2831853;
    float cosA = cos(angle);
    float sinA = sin(angle);
    mat2 rot = mat2(cosA, -sinA, sinA, cosA);

    const vec2 offsets[4] = vec2[4](
        vec2( 1.0,  0.3),
        vec2(-1.0, -0.3),
        vec2(-0.3,  1.0),
        vec2( 0.3, -1.0)
    );

    float occ = 0.0;
    for (int i = 0; i < 4; ++i) {
        vec2 sampleUV = clamp(uv + (rot * offsets[i]) * radius, vec2(0.001), vec2(0.999));
        float sampleDepth = texture(gDepth, sampleUV).r;
        if (sampleDepth >= 0.99999) continue;
        vec3 samplePos = reconstructCameraRelativePos(sampleUV, sampleDepth);
        vec3 diff = samplePos - camRelPos;
        float d2 = dot(diff, diff);
        if (d2 > 2.0 || d2 < 0.01) continue;
        float vDotN = dot(diff * inversesqrt(d2), N);
        float rangeWeight = 1.0 - (d2 / 2.0);
        occ += clamp(vDotN - 0.18, 0.0, 1.0) * rangeWeight;
    }
    return clamp(1.0 - occ * 0.25, 0.35, 1.0);
}

void main() {
    float depth = texture(gDepth, v_TexCoord).r;
    vec3 camRelPos = reconstructCameraRelativePos(v_TexCoord, depth);
    vec3 V = normalize(-camRelPos);

    // Sky early-out
    if (depth >= 0.99999) {
        outHdrColor = vec4(evaluatePhysicalSky(-V), 1.0);
        return;
    }

    vec4 albRough = texture(gAlbedoRoughness, v_TexCoord);
    vec4 normMet  = texture(gNormalMetallic, v_TexCoord);
    vec4 lightEm  = texture(gLightEmission, v_TexCoord);

    vec3 albedo    = albRough.rgb;
    float roughness = albRough.a;
    vec3 N         = normalize(normMet.rgb * 2.0 - 1.0);

    float metallic;
    uint materialId;
    unpackMetallicAndMaterial(normMet.a, metallic, materialId);

    float blockLight = lightEm.r;
    float skyLight   = lightEm.g;
    float emissive   = lightEm.b;
    float vertexAO   = lightEm.a;

    // Weather wetness gloss on upward-facing outdoor surfaces
    float wetness = u_Weather.y * OPT_RAIN_PUDDLES * smoothstep(0.65, 0.95, skyLight);
    if (wetness > 0.01 && N.y > 0.25) {
        float puddleFactor = wetness * smoothstep(0.25, 0.85, N.y);
        roughness = mix(roughness, 0.08, puddleFactor * 0.85);
        albedo   *= mix(1.0, 0.72, puddleFactor * 0.5);
    }

    // Combined multi-bounce Ambient Occlusion (keeps shadows colorful and warm, never muddy black)
    float ssao = evaluateFastContactAO(v_TexCoord, camRelPos, N);
    float combinedAO = clamp(vertexAO * ssao, 0.12, 1.0);
    vec3 multiBounceAO = gtaoMultiBounce(combinedAO, albedo);

    // Cascaded Shadow evaluation
    float shadowVis = evaluateCascadedShadow(shadowMapArray, camRelPos, N, gl_FragCoord.xy);
    // Cave leak prevention: attenuate sunlight inside deep unlit caves
    shadowVis *= smoothstep(0.02, 0.22, skyLight);

    // Subsurface scattering strength from material ID
    float sss = (materialId == MAT_FOLIAGE_WAVING || materialId == MAT_LEAVES) ? (0.75 * OPT_SUBSURFACE_SCATTERING) : 0.0;
    if (materialId == MAT_ICE || materialId == MAT_SLIME_HONEY) sss = 0.55 * OPT_SUBSURFACE_SCATTERING;

    // 1. Direct Sun & Moon PBR Lighting
    vec3 sunRadiance  = u_SunColor.rgb * u_SunColor.w * OPT_SUNLIGHT_INTENSITY * (1.0 - u_Weather.x * 0.78);
    vec3 moonRadiance = u_MoonColor.rgb * u_MoonColor.w * 0.45 * OPT_SUNLIGHT_INTENSITY * (1.0 - u_Weather.x * 0.78);

    vec3 directLighting = vec3(0.0);
    if (u_SunDirection.w > -0.05) {
        directLighting += evaluateDirectPBR(N, V, u_SunDirection.xyz, albedo, roughness, metallic, sss, sunRadiance, shadowVis);
    }
    if (u_MoonDirection.y > -0.05) {
        directLighting += evaluateDirectPBR(N, V, u_MoonDirection.xyz, albedo, roughness, metallic, sss, moonRadiance, shadowVis);
    }

    // 2. Hemispherical Sky & Warm Ground Bounce Ambient
    vec3 zenithAmb  = evaluateAtmosphericHazeSky(vec3(0.0, 1.0, 0.0), 0.75);
    vec3 horizonAmb = evaluateAtmosphericHazeSky(normalize(vec3(N.x, 0.15, N.z) + 1.0e-4), 0.75);
    vec3 groundAmb  = zenithAmb * vec3(0.38, 0.34, 0.28) + albedo * 0.15;

    float hemiWeight = N.y * 0.5 + 0.5;
    vec3 skyIrradiance = mix(groundAmb, mix(horizonAmb, zenithAmb, clamp(N.y, 0.0, 1.0)), hemiWeight);
    float skyExposure = pow(skyLight, 1.45) * OPT_AMBIENT_INTENSITY;
    // Minimum baseline ambient for caves/night so geometry remains legible
    vec3 baseCaveAmb = vec3(0.012, 0.015, 0.024) * (1.0 + u_Environment.w * 8.0);
    vec3 ambientDiffuse = albedo * (1.0 - metallic) * (skyIrradiance * skyExposure + baseCaveAmb) * multiBounceAO;

    // 3. Analytical Environment Specular Reflection (IBL)
    vec3 R = reflect(-V, N);
    float NoV = clamp(abs(dot(N, V)), 0.0, 1.0);
    vec3 f0 = mix(vec3(0.04), albedo, metallic);
    vec3 F_env = F_SchlickRoughness(NoV, f0, roughness);
    vec3 envSky = evaluateAtmosphericHazeSky(R, 0.85) * smoothstep(0.05, 0.45, skyLight);
    vec3 envSpecular = envSky * F_env * pow(1.0 - roughness, 2.2) * combinedAO;

    // 4. Warm Inverse-Square Blocklight (Torches, Lanterns, Glowstone)
    float blCurve = blockLight * blockLight * (0.65 + 0.35 * blockLight);
    vec3 torchColor = mix(vec3(1.0, 0.45, 0.14), vec3(1.0, 0.78, 0.42), blockLight);
    vec3 blockLighting = albedo * torchColor * blCurve * u_BlockLightColor.w * 1.45 * multiBounceAO;

    // 5. Handheld Dynamic Point Light
    if (u_Environment.z > 0.5 && OPT_HANDHELD_DYNAMIC_LIGHT > 0.01) {
        float distSq = dot(camRelPos, camRelPos);
        float radius = max(u_HeldLightColor.w, 8.0);
        float atten = clamp(1.0 - distSq / (radius * radius), 0.0, 1.0);
        atten *= atten / (1.0 + distSq * 0.18);
        vec3 L_held = normalize(-camRelPos);
        float heldNoL = clamp(dot(N, L_held), 0.0, 1.0) * 0.7 + 0.3;
        blockLighting += albedo * u_HeldLightColor.rgb * atten * heldNoL * OPT_HANDHELD_DYNAMIC_LIGHT * 1.6 * combinedAO;
    }

    // 6. Emissive Glow
    vec3 emissiveLight = albedo * emissive * OPT_EMISSIVE_STRENGTH * 4.2;

    vec3 totalHdr = directLighting + ambientDiffuse + envSpecular + blockLighting + emissiveLight;

    // 7. Distance Aerial Perspective Haze (Rich depth layering for distant terrain & sky islands)
    float viewDist = length(camRelPos);
    float fogEnd   = max(u_FogParams.y, 128.0);
    float hazeFactor = (1.0 - exp(-viewDist / (fogEnd * 0.72))) * OPT_ATMOS_HAZINESS * 0.68;
    // Height attenuation so high-altitude islands stay clearer than deep valleys
    float worldY = camRelPos.y + u_CameraPos.y;
    hazeFactor *= clamp(exp(-(worldY - 64.0) * 0.004), 0.25, 1.35);
    hazeFactor = clamp(hazeFactor, 0.0, 0.92);

    vec3 hazeColor = evaluateAtmosphericHazeSky(-V, max(0.65, OPT_ATMOS_HAZINESS));
    totalHdr = mix(totalHdr, hazeColor, hazeFactor);

    outHdrColor = vec4(max(totalHdr, vec3(0.0)), 1.0);
}
