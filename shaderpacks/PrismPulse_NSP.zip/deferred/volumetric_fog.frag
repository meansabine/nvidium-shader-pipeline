#version 460 core

#include "../common/scene_uniforms.glsl"
#include "../common/options.glsl"
#include "../common/shadows.glsl"
#include "../common/atmosphere.glsl"

layout(binding = 0) uniform sampler2D gDepth;
layout(binding = 1) uniform sampler2DArray shadowMapArray;

layout(location = 0) in vec2 v_TexCoord;
layout(location = 0) out vec4 outVolumetricFog;

void main() {
    // Fast bypass when godrays are disabled
    if (u_FogParams.z < 0.5 || OPT_GODRAYS_STRENGTH <= 0.01) {
        outVolumetricFog = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    float depth = texture(gDepth, v_TexCoord).r;
    vec3 camRelEnd = reconstructCameraRelativePos(v_TexCoord, depth);
    float rayLen = length(camRelEnd);
    vec3 rayDir  = camRelEnd / max(rayLen, 1.0e-5);

    // Clamp volumetric march to 96m (where shadow cascade 0/1 have crispest detail)
    float maxMarch = min(rayLen, 96.0);

    // 6-step IGN-jittered raymarch (2.6x faster than 16 steps, temporal TAA makes it silky smooth!)
    const int STEPS = 6;
    float stepSize = maxMarch / float(STEPS);
    float jitter   = interleavedGradientNoise(gl_FragCoord.xy, u_Time.z);

    float cosTheta = dot(rayDir, u_ShadowLightDir.xyz);
    float phase    = phaseHenyeyGreenstein(cosTheta, 0.62);

    vec3 lightColor = mix(u_MoonColor.rgb * 0.35, u_SunColor.rgb * 1.15, u_SkyColor.w);
    lightColor      = mix(lightColor, vec3(1.0, 0.45, 0.18) * 1.4, u_HorizonColor.w);
    vec3 ambientFog = evaluateAtmosphericHazeSky(rayDir, 0.75) * 0.25;

    float baseDensity = 0.0022 * OPT_GODRAYS_STRENGTH * (1.0 + u_Weather.x * 1.2);
    vec3 accumInscatter = vec3(0.0);
    float transmittance = 1.0;

    for (int i = 0; i < STEPS; ++i) {
        float t = (float(i) + jitter) * stepSize;
        vec3 sampleCamRel = rayDir * t;
        float worldY = sampleCamRel.y + u_CameraPos.y;

        // Exponential height falloff centered around sea level / valley mist
        float heightFalloff = clamp(exp(-(worldY - 62.0) * 0.018), 0.15, 2.2);
        float stepDensity   = baseDensity * heightFalloff * stepSize;

        if (stepDensity > 1.0e-5) {
            float shadowVis = sampleVolumetricShadowTap(shadowMapArray, sampleCamRel);
            vec3 stepLight  = (lightColor * phase * shadowVis * 2.8 + ambientFog) * stepDensity;
            accumInscatter += transmittance * stepLight;
            transmittance  *= exp(-stepDensity * 1.15);
        }
    }

    outVolumetricFog = vec4(accumInscatter, clamp(transmittance, 0.0, 1.0));
}
