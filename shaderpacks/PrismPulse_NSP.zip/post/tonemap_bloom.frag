#version 460 core

#include "../common/scene_uniforms.glsl"
#include "../common/options.glsl"
#include "../common/post_tonemap.glsl"

layout(binding = 0) uniform sampler2D hdrSceneTex;
layout(binding = 1) uniform sampler2D volumetricFogTex;
layout(binding = 2) uniform sampler2D gLightEmission;
layout(binding = 3) uniform sampler2D gDepth;
layout(binding = 4) uniform sampler2D prevHistoryTex;
layout(binding = 5) uniform sampler2D gNormalMetallic;

layout(location = 0) in vec2 v_TexCoord;
layout(location = 0) out vec4 outColor;

// Fast 3-Mip Hardware Pyramid Bloom (replaces 45-tap 5-octave tent filters with 3 bilinear mip taps!)
vec3 sampleFastPyramidBloom(vec2 uv) {
    vec3 m2 = textureLod(hdrSceneTex, uv, 2.0).rgb;
    vec3 m3 = textureLod(hdrSceneTex, uv, 3.5).rgb;
    vec3 m5 = textureLod(hdrSceneTex, uv, 5.0).rgb;
    vec3 combined = m2 * 0.45 + m3 * 0.35 + m5 * 0.20;
    float luma = dot(combined, vec3(0.2126, 0.7152, 0.0722));
    float knee = smoothstep(0.65, 1.85, luma);
    return combined * knee;
}

vec3 rgbToYCoCg(vec3 c) {
    return vec3(
         0.25 * c.r + 0.5 * c.g + 0.25 * c.b,
         0.50 * c.r             - 0.50 * c.b,
        -0.25 * c.r + 0.5 * c.g - 0.25 * c.b
    );
}

vec3 yCoCgToRgb(vec3 ycc) {
    float tmp = ycc.x - ycc.z;
    return vec3(tmp + ycc.y, ycc.x + ycc.z, tmp - ycc.y);
}

void main() {
    vec3 hdrColor = texture(hdrSceneTex, v_TexCoord).rgb;
    vec4 volFog   = texture(volumetricFogTex, v_TexCoord);

    // 1. Composite Volumetric Fog & Light Shafts
    hdrColor = hdrColor * volFog.a + volFog.rgb;

    // 2. Add soft atmospheric bloom
    float bloomStrength = max(u_PostParams.y, 0.08);
    if (bloomStrength > 0.005) {
        hdrColor += sampleFastPyramidBloom(v_TexCoord) * bloomStrength * 0.45;
    }

    // 3. Exposure, Perceptual OKLab Vibrancy Grading, and Tonemapping
    float exposure  = max(u_PostParams.x, 0.1);
    float userSat   = (u_PostParams.z > 0.01) ? u_PostParams.z : 1.0;
    int tonemapOp   = int(round(u_PostParams.w));

    vec3 exposedLinear = hdrColor * exposure;
    vec3 gradedLinear  = applyColorGrading(exposedLinear, userSat);
    vec3 tonemapped    = applySelectedTonemap(gradedLinear, tonemapOp);
    vec3 currSrgb      = linearToSrgb(tonemapped);

    // 4. Lightweight 5-Tap YCoCg Neighborhood-Clamped TAA
    if (u_DebugParams.y > 0.5 && u_CameraDelta.w > 0.5) {
        float depth = texture(gDepth, v_TexCoord).r;
        vec3 camRelPos = reconstructCameraRelativePos(v_TexCoord, depth);
        vec3 prevCamRelPos = camRelPos + u_CameraDelta.xyz;
        vec4 prevClip = u_PrevViewProjMatrix * vec4(prevCamRelPos, 1.0);
        vec2 prevUV = (prevClip.xy / max(prevClip.w, 1.0e-6)) * 0.5 + 0.5;

        if (all(greaterThanEqual(prevUV, vec2(0.001))) && all(lessThanEqual(prevUV, vec2(0.999)))) {
            vec2 texel = u_ScreenSize.zw;
            vec3 c0 = rgbToYCoCg(currSrgb);
            vec3 cN = rgbToYCoCg(linearToSrgb(applySelectedTonemap( texture(hdrSceneTex, v_TexCoord + vec2(0.0,  texel.y)).rgb * exposure, tonemapOp)));
            vec3 cS = rgbToYCoCg(linearToSrgb(applySelectedTonemap( texture(hdrSceneTex, v_TexCoord + vec2(0.0, -texel.y)).rgb * exposure, tonemapOp)));
            vec3 cE = rgbToYCoCg(linearToSrgb(applySelectedTonemap( texture(hdrSceneTex, v_TexCoord + vec2( texel.x, 0.0)).rgb * exposure, tonemapOp)));
            vec3 cW = rgbToYCoCg(linearToSrgb(applySelectedTonemap( texture(hdrSceneTex, v_TexCoord + vec2(-texel.x, 0.0)).rgb * exposure, tonemapOp)));

            vec3 boxMin = min(c0, min(min(cN, cS), min(cE, cW)));
            vec3 boxMax = max(c0, max(max(cN, cS), max(cE, cW)));

            vec3 histYcc = clamp(rgbToYCoCg(texture(prevHistoryTex, prevUV).rgb), boxMin, boxMax);
            vec3 histRgb = yCoCgToRgb(histYcc);

            float velocity = length((v_TexCoord - prevUV) * u_ScreenSize.xy);
            float blend = clamp(mix(0.88, 0.50, clamp(velocity * 0.15, 0.0, 1.0)), 0.0, 0.92);
            currSrgb = mix(currSrgb, histRgb, blend);
        }
    }

    outColor = vec4(clamp(currSrgb, 0.0, 1.0), 1.0);
}
