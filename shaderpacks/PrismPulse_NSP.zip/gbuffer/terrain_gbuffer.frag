#version 460 core
#extension GL_ARB_shading_language_include : enable
#pragma optionNV(unroll all)
#define UNROLL_LOOP
#extension GL_NV_gpu_shader5 : require
#extension GL_NV_bindless_texture : require
#extension GL_NV_shader_buffer_load : require
#extension GL_NV_fragment_shader_barycentric : require

#import <nvidium:occlusion/scene.glsl>
#import <nvidium:terrain/vertex_format.glsl>

#include "../common/scene_uniforms.glsl"
#include "../common/options.glsl"
#include "../common/materials.glsl"
#include "../common/post_tonemap.glsl"

layout(binding = 0) uniform sampler2D tex_diffuse;
layout(binding = 1) uniform sampler2D tex_light;
layout(binding = 2) uniform sampler2D tex_normal;
layout(binding = 3) uniform sampler2D tex_specular;

layout(location = 5) in NvidiumVertexData {
    vec2 v_uv;
    vec3 v_color;
    vec2 v_lightUV;
} nv_in;

layout(location = 0) out vec4 outAlbedoRoughness;
layout(location = 1) out vec4 outNormalMetallic;
layout(location = 2) out vec4 outLightEmission;

void main() {
    uint quadId = uint(gl_PrimitiveID) >> 4;
    bool triangle0 = ((uint(gl_PrimitiveID) >> 3) & 1u) == 0u;
    uvec3 triIndices = triangle0 ? uvec3(0u, 1u, 2u) : uvec3(2u, 3u, 0u);

    Vertex V0 = terrainData[(quadId << 2) + triIndices.x];
    Vertex V1 = terrainData[(quadId << 2) + triIndices.y];
    Vertex V2 = terrainData[(quadId << 2) + triIndices.z];

    vec2 uv = nv_in.v_uv;
    float lodBias = (((gl_PrimitiveID >> 2) & 1) != 0) ? -8.0 : -0.35;
    vec4 diffSample = texture(tex_diffuse, uv, lodBias);

    float alphaCutoff = getVertexAlphaCutoff(uint(gl_PrimitiveID) & 3u);
    if (diffSample.a < alphaCutoff) {
        discard;
    }

    // Exact geometric face normal computed analytically from vertex quad geometry
    // Completely eliminates edge derivative explosion and thin black block outlines
    vec3 pos0 = decodeVertexPosition(V0);
    vec3 pos1 = decodeVertexPosition(V1);
    vec3 pos2 = decodeVertexPosition(V2);

    vec3 edge1 = pos1 - pos0;
    vec3 edge2 = pos2 - pos0;
    vec3 geoNormal = cross(edge1, edge2);
    float geomLen = length(geoNormal);
    geoNormal = (geomLen > 1.0e-6) ? (geoNormal / geomLen) : vec3(0.0, 1.0, 0.0);
    if (!gl_FrontFacing) {
        geoNormal = -geoNormal;
    }

    // Separate vertex ambient occlusion from biome tint and undo vanilla cardinal face shade
    float maxChannel = max(nv_in.v_color.r, max(nv_in.v_color.g, nv_in.v_color.b));
    vec3 biomeTint = (maxChannel > 1.0e-4) ? (nv_in.v_color / maxChannel) : vec3(1.0);
    float vanillaFaceFactor = (geoNormal.y < -0.5) ? 0.5 : ((abs(geoNormal.y) > 0.5) ? 1.0 : ((abs(geoNormal.z) > 0.5) ? 0.6 : 0.8));
    float vertexAO = clamp(maxChannel / max(vanillaFaceFactor, 0.5), 0.15, 1.0);

    vec3 srgbAlbedo = diffSample.rgb * biomeTint;
    vec3 linearAlbedo = srgbToLinear(srgbAlbedo);

    vec3 worldNormal = geoNormal;
    if (OPT_NORMAL_BUMP_STRENGTH > 0.01) {
        vec4 normSample = texture(tex_normal, uv, lodBias);
        vec2 labXY = normSample.xy * 2.0 - 1.0;
        if (dot(labXY, labXY) > 0.002) {
            vec2 uv0 = decodeVertexUV(V0);
            vec2 uv1 = decodeVertexUV(V1);
            vec2 uv2 = decodeVertexUV(V2);
            vec2 duv1 = uv1 - uv0;
            vec2 duv2 = uv2 - uv0;
            float det = duv1.x * duv2.y - duv2.x * duv1.y;
            vec3 T;
            vec3 B;
            if (abs(det) > 1.0e-7) {
                float invDet = 1.0 / det;
                T = normalize((edge1 * duv2.y - edge2 * duv1.y) * invDet);
                B = normalize((edge2 * duv1.x - edge1 * duv2.x) * invDet);
            } else {
                vec3 upRef = abs(geoNormal.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
                T = normalize(cross(upRef, geoNormal));
                B = cross(geoNormal, T);
            }
            labXY *= OPT_NORMAL_BUMP_STRENGTH;
            float nz = sqrt(max(1.0 - dot(labXY, labXY), 0.01));
            worldNormal = normalize(T * labXY.x + B * labXY.y + geoNormal * nz);
            vertexAO *= clamp(normSample.z, 0.25, 1.0);
        }
    }

    vec4 specSample = texture(tex_specular, uv, lodBias);
    uint matId = decodeVertexMaterial(V0);
    MaterialParams mat = evaluateBlockMaterial(matId, linearAlbedo, specSample, nv_in.v_lightUV);

    float blockLight = clamp(nv_in.v_lightUV.x, 0.0, 1.0);
    float skyLight   = clamp(nv_in.v_lightUV.y, 0.0, 1.0);

    outAlbedoRoughness = vec4(linearAlbedo, mat.roughness);
    outNormalMetallic  = vec4(worldNormal * 0.5 + 0.5, packMetallicAndMaterial(mat.metallic, matId));
    outLightEmission   = vec4(blockLight, skyLight, mat.emissive, vertexAO);
}
