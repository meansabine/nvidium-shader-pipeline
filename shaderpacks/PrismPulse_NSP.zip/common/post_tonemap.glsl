#ifndef POST_TONEMAP_GLSL
#define POST_TONEMAP_GLSL

vec3 srgbToLinear(vec3 srgb) {
    return pow(max(srgb, vec3(0.0)), vec3(2.2));
}

vec3 linearToSrgb(vec3 lin) {
    return pow(max(lin, vec3(0.0)), vec3(1.0 / 2.2));
}

// Troy Sobotka / Blender AgX Punchy Tonemapper
vec3 tonemapAgX(vec3 color) {
    const mat3 agxIn = mat3(
        0.842479062253094,  0.0423282422610123, 0.0423756549057051,
        0.0784335999999992, 0.878468636469772,  0.0784336,
        0.0792237451477643, 0.0791661274605434, 0.879142973793104
    );
    const mat3 agxOut = mat3(
         1.19687900512017,  -0.0528968517574562, -0.0529716355144438,
        -0.0980208811401368, 1.15190312990417,   -0.0980434501171241,
        -0.0990297440797205, -0.0989611768448433, 1.15107367264116
    );
    vec3 val = agxIn * max(color, vec3(1.0e-6));
    val = clamp((log2(val) + 12.47393) / 16.5, 0.0, 1.0);
    vec3 x2 = val * val;
    vec3 x4 = x2 * x2;
    val = 15.5 * x4 * x2 - 40.14 * x4 * val + 31.96 * x4 - 6.868 * x2 * val + 0.4298 * x2 + 0.1191 * val - 0.00232;
    val = agxOut * val;
    // Golden-vibrant punch curve
    return clamp(pow(max(val, vec3(0.0)), vec3(1.18)), 0.0, 1.0);
}

vec3 tonemapACES(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

vec3 tonemapKhronosNeutral(vec3 color) {
    const float startCompression = 0.76;
    const float desaturation = 0.12;
    float x = min(color.r, min(color.g, color.b));
    float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
    color -= offset;
    float peak = max(color.r, max(color.g, color.b));
    if (peak < startCompression) return color;
    float d = 1.0 - startCompression;
    float newPeak = 1.0 - d * d / (peak + d - startCompression);
    color *= newPeak / peak;
    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    return mix(color, vec3(newPeak), g);
}

vec3 applySelectedTonemap(vec3 hdrLinear, int operatorId) {
    if (operatorId == 1) return tonemapACES(hdrLinear);
    if (operatorId == 2) return tonemapKhronosNeutral(hdrLinear);
    return tonemapAgX(hdrLinear);
}

// Perceptual OKLab Chroma/Vibrancy Grading: boosts muted natural colors while protecting already-saturated hues from neon clipping!
vec3 applyColorGrading(vec3 linColor, float userSaturation) {
    // Linear sRGB ->LMS -> OKLab
    float l = 0.4122214708 * linColor.r + 0.5363325363 * linColor.g + 0.0514459929 * linColor.b;
    float m = 0.2119034982 * linColor.r + 0.6806995451 * linColor.g + 0.1073969566 * linColor.b;
    float s = 0.0883024619 * linColor.r + 0.2817188376 * linColor.g + 0.6299787005 * linColor.b;

    float l_ = pow(max(l, 0.0), 1.0 / 3.0);
    float m_ = pow(max(m, 0.0), 1.0 / 3.0);
    float s_ = pow(max(s, 0.0), 1.0 / 3.0);

    float L = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_;
    float a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_;
    float b = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_;

    // Smart Vibrancy: lift low-to-mid chroma, roll off high chroma so nothing looks radioactive
    float chroma = sqrt(a * a + b * b);
    float vibrancyLift = 1.24 * (1.0 - 0.45 * smoothstep(0.08, 0.28, chroma));
    float finalScale = vibrancyLift * clamp(userSaturation, 0.5, 2.0);

    a *= finalScale;
    b *= finalScale;

    // Subtle S-curve contrast in perceptual lightness L
    L = clamp(mix(L, smoothstep(0.0, 1.0, L), 0.14), 0.0, 1.0);

    // OKLab -> LMS -> Linear sRGB
    float l_out = L + 0.3963377774 * a + 0.2158037573 * b;
    float m_out = L - 0.1055613458 * a - 0.0638541728 * b;
    float s_out = L - 0.0894841775 * a - 1.2914855480 * b;

    float l3 = l_out * l_out * l_out;
    float m3 = m_out * m_out * m_out;
    float s3 = s_out * s_out * s_out;

    vec3 rgb;
    rgb.r = +4.0767416621 * l3 - 3.3077115913 * m3 + 0.2309699292 * s3;
    rgb.g = -1.2684380046 * l3 + 2.6097574011 * m3 - 0.3413193965 * s3;
    rgb.b = -0.0041960863 * l3 - 0.7034186147 * m3 + 1.7076147010 * s3;

    return max(rgb, vec3(0.0));
}

#endif
