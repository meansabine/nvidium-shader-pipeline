#ifndef SCENE_UNIFORMS_GLSL
#define SCENE_UNIFORMS_GLSL

layout(std140, binding = 3) uniform SceneUniforms {
    mat4 u_ViewMatrix;
    mat4 u_ProjMatrix;
    mat4 u_ViewProjMatrix;
    mat4 u_InvViewProjMatrix;
    mat4 u_PrevViewProjMatrix;

    mat4 u_CascadeViewProj0;
    mat4 u_CascadeViewProj1;
    mat4 u_CascadeViewProj2;
    vec4 u_CascadeSplits;

    vec4 u_SunDirection;
    vec4 u_SunColor;
    vec4 u_MoonDirection;
    vec4 u_MoonColor;
    vec4 u_ShadowLightDir;

    vec4 u_SkyColor;
    vec4 u_HorizonColor;
    vec4 u_BlockLightColor;

    vec4 u_CameraPos;
    vec4 u_ScreenSize;
    vec4 u_Time;
    vec4 u_Weather;
    vec4 u_Environment;
    vec4 u_HeldLightColor;
    vec4 u_FogColor;
    vec4 u_FogParams;
    vec4 u_PostParams;
    vec4 u_ShadowParams;
    vec4 u_DebugParams;
    vec4 u_CameraDelta;
    vec4 u_TaaJitter;
};

const int MAX_POINT_LIGHTS = 64;

layout(std140, binding = 5) uniform PointLightUniforms {
    vec4 u_PointLightMeta;
    vec4 u_PointLightPosRadius[MAX_POINT_LIGHTS];
    vec4 u_PointLightColor[MAX_POINT_LIGHTS];
};

vec3 reconstructCameraRelativePos(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 relPos = u_InvViewProjMatrix * clip;
    return relPos.xyz / max(relPos.w, 1.0e-7);
}

vec3 reconstructWorldPos(vec2 uv, float depth) {
    return reconstructCameraRelativePos(uv, depth) + u_CameraPos.xyz;
}

vec3 projectCameraRelativeToUVDepth(vec3 camRelPos) {
    vec4 clip = u_ViewProjMatrix * vec4(camRelPos, 1.0);
    if (clip.w <= 1.0e-5) return vec3(-1.0);
    vec3 ndc = clip.xyz / clip.w;
    return ndc * 0.5 + 0.5;
}

float interleavedGradientNoise(vec2 pixelCoord, float frameOffset) {
    vec2 p = pixelCoord + frameOffset * 5.588238;
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

// Ultra-fast analytical value noise (single octave ready)
float noise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash12(i + vec2(0.0, 0.0)), hash12(i + vec2(1.0, 0.0)), u.x),
        mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), u.x),
        u.y
    );
}

// Lightweight 2-octave FBM instead of heavy 5-octave loops
float fbm2D(vec2 p) {
    float v = 0.65 * noise2D(p);
    p = mat2(1.6, -1.2, 1.2, 1.6) * p;
    v += 0.35 * noise2D(p);
    return v;
}

mat4 getCascadeViewProj(int cascadeIdx) {
    if (cascadeIdx == 0) return u_CascadeViewProj0;
    if (cascadeIdx == 1) return u_CascadeViewProj1;
    return u_CascadeViewProj2;
}

#endif
