#ifndef PBR_BRDF_GLSL
#define PBR_BRDF_GLSL

const float PI = 3.14159265359;

float D_GGX(float NoH, float alpha) {
    float a2 = alpha * alpha;
    float d = (NoH * a2 - NoH) * NoH + 1.0;
    return a2 / max(PI * d * d, 1.0e-6);
}

// Fast Hammon-approximated Smith GGX Correlated visibility (eliminates 2 square roots per light!)
float V_SmithGGXFast(float NoV, float NoL, float alpha) {
    return 0.5 / max(mix(2.0 * NoL * NoV, NoL + NoV, alpha), 1.0e-5);
}

vec3 F_Schlick(float u, vec3 f0) {
    float f = 1.0 - u;
    float f2 = f * f;
    return f0 + (1.0 - f0) * (f2 * f2 * f);
}

vec3 F_SchlickRoughness(float cosTheta, vec3 f0, float roughness) {
    return f0 + (max(vec3(1.0 - roughness), f0) - f0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
}

// Richer diffuse with subtle retro-reflection at grazing angles
float Fd_BurleyFast(float NoV, float NoL, float LoH, float roughness) {
    float fd90 = 0.5 + 2.0 * LoH * LoH * roughness;
    float lightScatter = 1.0 + (fd90 - 1.0) * pow(1.0 - NoL, 5.0);
    float viewScatter  = 1.0 + (fd90 - 1.0) * pow(1.0 - NoV, 5.0);
    return (lightScatter * viewScatter) * (1.0 / PI);
}

// Jimenez multi-bounce AO approximation: injects warm saturated bounce into shadows instead of dirty black
vec3 gtaoMultiBounce(float visibility, vec3 albedo) {
    vec3 a =  2.0404 * albedo - 0.3324;
    vec3 b = -4.7951 * albedo + 0.6417;
    vec3 c =  2.7552 * albedo + 0.6903;
    return max(vec3(visibility), ((visibility * a + b) * visibility + c) * visibility);
}

vec3 evaluateDirectPBR(
    vec3 N, vec3 V, vec3 L,
    vec3 albedo, float roughness, float metallic, float sss,
    vec3 lightColor, float shadowVis
) {
    vec3 H = normalize(V + L);
    float NoV = clamp(abs(dot(N, V)) + 1.0e-5, 0.0, 1.0);
    float NoL = clamp(dot(N, L), 0.0, 1.0);
    float NoH = clamp(dot(N, H), 0.0, 1.0);
    float LoH = clamp(dot(L, H), 0.0, 1.0);

    float alpha = max(roughness * roughness, 0.002);
    vec3 f0 = mix(vec3(0.04), albedo, metallic);

    // Specular BRDF
    float D = D_GGX(NoH, alpha);
    float Vis = V_SmithGGXFast(NoV, NoL, alpha);
    vec3  F = F_Schlick(LoH, f0);
    vec3 specular = (D * Vis) * F * NoL * shadowVis;

    // Diffuse BRDF with wrapped Subsurface Scattering for vibrant foliage & ice
    float diffuseTerm = Fd_BurleyFast(NoV, NoL, LoH, roughness) * NoL * shadowVis;
    
    // Forward & wrap translucency when sss > 0
    vec3 sssContrib = vec3(0.0);
    if (sss > 0.01) {
        float wrapNoL = clamp((dot(N, L) + 0.45) / 1.45, 0.0, 1.0);
        float backScatter = pow(clamp(dot(V, -L), 0.0, 1.0), 3.0) * 0.65 + wrapNoL * 0.45;
        // Tint subsurface light slightly warmer/greener through the block's own chroma
        vec3 sssTint = pow(max(albedo, vec3(0.02)), vec3(0.75)) * 1.35;
        sssContrib = sssTint * backScatter * sss * (0.25 + 0.75 * shadowVis) * (1.0 / PI);
    }

    vec3 kD = (1.0 - F) * (1.0 - metallic);
    vec3 diffuse = kD * (albedo * diffuseTerm + sssContrib);

    return (diffuse + specular) * lightColor;
}

#endif
