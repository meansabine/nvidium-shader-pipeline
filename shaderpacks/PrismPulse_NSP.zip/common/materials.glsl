#ifndef MATERIALS_GLSL
#define MATERIALS_GLSL

const uint MAT_SOLID          = 0u;
const uint MAT_WATER          = 1u;
const uint MAT_LAVA           = 2u;
const uint MAT_FOLIAGE_WAVING = 3u;
const uint MAT_LEAVES         = 4u;
const uint MAT_GLASS          = 5u;
const uint MAT_ICE            = 6u;
const uint MAT_EMISSIVE       = 7u;
const uint MAT_METAL          = 8u;
const uint MAT_GEM            = 9u;
const uint MAT_POLISHED       = 10u;
const uint MAT_WET            = 11u;
const uint MAT_SAND_SNOW      = 12u;
const uint MAT_PORTAL         = 13u;
const uint MAT_SLIME_HONEY    = 14u;
const uint MAT_ORE            = 15u;

struct MaterialParams {
    float roughness;
    float metallic;
    float emissive;
    float sss;
};

float packMetallicAndMaterial(float metallic, uint materialId) {
    float m = clamp(metallic, 0.0, 0.98);
    return float(materialId & 31u) + m;
}

void unpackMetallicAndMaterial(float packedVal, out float metallic, out uint materialId) {
    float floored = floor(max(0.0, packedVal) + 1.0e-4);
    materialId = uint(clamp(floored, 0.0, 31.0));
    metallic = clamp((packedVal - floored) / 0.98, 0.0, 1.0);
}

MaterialParams evaluateBlockMaterial(uint materialId, vec3 linearAlbedo, vec4 labPbrSpec, vec2 lightUV) {
    MaterialParams mat;
    float luma = dot(linearAlbedo, vec3(0.2126, 0.7152, 0.0722));
    
    // Subtle micro-contrast on roughness so blocks feel tactile, not flat plastic
    mat.roughness = clamp(0.82 - (luma - 0.35) * 0.18, 0.25, 0.95);
    mat.metallic  = 0.0;
    mat.emissive  = 0.0;
    mat.sss       = 0.0;

    if (materialId == MAT_FOLIAGE_WAVING || materialId == MAT_LEAVES) {
        mat.roughness = 0.62;
        mat.sss       = (materialId == MAT_FOLIAGE_WAVING) ? 0.85 : 0.60;
    } else if (materialId == MAT_ICE || materialId == MAT_GLASS) {
        mat.roughness = 0.12;
        mat.sss       = (materialId == MAT_ICE) ? 0.45 : 0.0;
    } else if (materialId == MAT_METAL) {
        mat.roughness = clamp(0.28 - luma * 0.12, 0.10, 0.45);
        mat.metallic  = 0.88;
    } else if (materialId == MAT_GEM) {
        mat.roughness = 0.14;
        mat.metallic  = 0.15;
        mat.sss       = 0.35;
    } else if (materialId == MAT_POLISHED) {
        mat.roughness = clamp(0.32 - luma * 0.10, 0.15, 0.48);
    } else if (materialId == MAT_WET) {
        mat.roughness = 0.20;
    } else if (materialId == MAT_SAND_SNOW) {
        mat.roughness = 0.72;
        mat.sss       = 0.25;
    } else if (materialId == MAT_EMISSIVE || materialId == MAT_LAVA || materialId == MAT_PORTAL) {
        mat.roughness = 0.40;
        mat.emissive  = 1.0;
    } else if (materialId == MAT_ORE) {
        // Highlight ore veins based on color saturation/brightness difference
        float chroma = max(linearAlbedo.r, max(linearAlbedo.g, linearAlbedo.b)) - min(linearAlbedo.r, min(linearAlbedo.g, linearAlbedo.b));
        float veinMask = smoothstep(0.12, 0.35, chroma + luma * 0.3);
        mat.roughness = mix(0.80, 0.22, veinMask);
        mat.metallic  = mix(0.0, 0.65, veinMask);
        mat.emissive  = veinMask * 0.28;
    } else if (materialId == MAT_SLIME_HONEY) {
        mat.roughness = 0.18;
        mat.sss       = 0.75;
    }

    // LabPBR 1.3 override if resourcepack provides specular atlas (_s)
    if (labPbrSpec.r > 0.004 || labPbrSpec.g > 0.004) {
        float perceptualSmooth = labPbrSpec.r;
        mat.roughness = clamp((1.0 - perceptualSmooth) * (1.0 - perceptualSmooth), 0.04, 0.99);
        if (labPbrSpec.g * 255.0 >= 230.0) {
            mat.metallic = 1.0;
        } else {
            mat.metallic = clamp(labPbrSpec.g, 0.0, 0.95);
        }
        if (labPbrSpec.b > 0.255) {
            mat.sss = clamp((labPbrSpec.b * 255.0 - 65.0) / 190.0, 0.0, 1.0);
        }
        if (labPbrSpec.a < 0.996 && labPbrSpec.a > 0.004) {
            mat.emissive = max(mat.emissive, labPbrSpec.a);
        }
    }

    return mat;
}

#endif
