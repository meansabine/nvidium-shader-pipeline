#ifndef ATMOSPHERE_GLSL
#define ATMOSPHERE_GLSL

#include "scene_uniforms.glsl"
#include "options.glsl"

float phaseHenyeyGreenstein(float cosTheta, float g) {
    float g2 = g * g;
    float denom = max(1.0 + g2 - 2.0 * g * cosTheta, 1.0e-4);
    return (1.0 - g2) / (4.0 * 3.14159265 * denom * sqrt(denom));
}

// Rich, golden-hour and cerulean sky synthesis without heavy multi-scattering integrals
vec3 evaluateAtmosphericHazeSky(vec3 V, float haziness) {
    int dimId = int(round(u_FogParams.w));
    if (dimId == -1) {
        // Nether warm ember gradient
        float h = clamp(V.y * 0.5 + 0.5, 0.0, 1.0);
        return mix(u_FogColor.rgb * vec3(1.35, 0.75, 0.55), u_FogColor.rgb * 0.45, h);
    }
    if (dimId == 1) {
        // End deep cosmic indigo-violet
        float h = abs(V.y);
        return mix(vec3(0.11, 0.05, 0.18), vec3(0.02, 0.01, 0.05), h);
    }

    float dayFactor = u_SkyColor.w;
    float sunsetFactor = u_HorizonColor.w;
    float rain = u_Weather.x;

    // Enhance zenith and horizon hues for a clean, vibrant atmospheric gradient
    vec3 dayZenith  = mix(u_SkyColor.rgb, vec3(0.12, 0.36, 0.88), 0.42);
    vec3 dayHorizon = mix(u_HorizonColor.rgb, vec3(0.55, 0.78, 0.98), 0.35);

    // Sunset / Sunrise warm magenta-amber glow
    vec3 sunsetZenith  = vec3(0.16, 0.22, 0.52);
    vec3 sunsetHorizon = vec3(0.98, 0.44, 0.20);

    // Night deep cobalt-indigo (never dead gray)
    vec3 nightZenith  = vec3(0.008, 0.018, 0.052);
    vec3 nightHorizon = vec3(0.025, 0.048, 0.110);

    vec3 zenith  = mix(nightZenith, dayZenith, dayFactor);
    vec3 horizon = mix(nightHorizon, dayHorizon, dayFactor);

    zenith  = mix(zenith, sunsetZenith, sunsetFactor * 0.75);
    horizon = mix(horizon, sunsetHorizon, sunsetFactor * 0.90);

    // Weather overcast desaturation
    vec3 rainColor = vec3(dot(horizon, vec3(0.299, 0.587, 0.114))) * vec3(0.72, 0.78, 0.85);
    zenith  = mix(zenith, rainColor * 0.65, rain * 0.85);
    horizon = mix(horizon, rainColor, rain * 0.85);

    float elev = clamp(V.y, 0.0, 1.0);
    float horizonCurve = pow(1.0 - elev, 2.6 / max(0.5, haziness));
    vec3 sky = mix(zenith, horizon, horizonCurve);

    // Forward Mie solar/lunar glow (disk-free so terrain haze never bleeds sun disks)
    float sunCos  = clamp(dot(V, u_SunDirection.xyz), 0.0, 1.0);
    float moonCos = clamp(dot(V, u_MoonDirection.xyz), 0.0, 1.0);
    vec3 mieGlow  = u_SunColor.rgb * pow(sunCos, 6.0) * (0.35 + 0.55 * sunsetFactor) * (1.0 - rain * 0.85);
    mieGlow      += u_MoonColor.rgb * pow(moonCos, 8.0) * 0.18 * (1.0 - dayFactor);

    return sky + mieGlow * haziness;
}

// Ultra-fast dual-layer planar clouds (Zero raymarching loops for 1:1 high FPS!)
vec4 evaluateFastSculptedClouds(vec3 V) {
    if (OPT_CLOUD_MODE < 0.5 || V.y <= 0.015) return vec4(0.0);

    float wind = u_Time.x * 0.018 * OPT_WIND_SPEED;
    vec2 planeUV = (V.xz / (V.y + 0.12)) * 1.35 + u_CameraPos.xz * 0.0008 + vec2(wind, wind * 0.4);

    // Primary cumulus-like sculpted FBM
    float n1 = fbm2D(planeUV * 1.8);
    // Secondary detail & directional sun-offset sample for self-shadowing
    vec2 lightOffset = u_ShadowLightDir.xz * 0.12;
    float n2 = fbm2D((planeUV + lightOffset) * 1.8 + vec2(3.7, 1.9));

    float thresh = 1.0 - OPT_CLOUD_COVERAGE * 0.78;
    float density = smoothstep(thresh, thresh + 0.28, n1);
    if (OPT_CLOUD_MODE > 1.5) {
        // Sculpted billowy mode adds a crisp second harmonic without loop overhead
        float detail = noise2D(planeUV * 5.2 - vec2(wind * 1.5, 0.0));
        density = smoothstep(thresh - 0.05, thresh + 0.22, n1 * 0.75 + detail * 0.25);
    }

    float selfShadow = clamp((n1 - n2) * 2.4 + 0.55, 0.15, 1.0);
    float cosLight = dot(V, u_ShadowLightDir.xyz);
    float silverLining = pow(clamp(cosLight, 0.0, 1.0), 6.0) * (1.0 - density * 0.6) * 1.4;

    vec3 directColor = mix(u_MoonColor.rgb * 0.35, u_SunColor.rgb * 1.25, u_SkyColor.w);
    directColor = mix(directColor, vec3(1.0, 0.48, 0.22) * 1.4, u_HorizonColor.w);
    vec3 ambientColor = mix(vec3(0.04, 0.07, 0.15), u_SkyColor.rgb * 0.85, u_SkyColor.w);

    vec3 cloudColor = mix(ambientColor, directColor, selfShadow) + directColor * silverLining;
    float horizonFade = smoothstep(0.015, 0.18, V.y);

    return vec4(cloudColor, density * horizonFade * 0.92);
}

vec3 evaluatePhysicalSky(vec3 V) {
    vec3 baseSky = evaluateAtmosphericHazeSky(V, max(0.6, OPT_ATMOS_HAZINESS));
    int dimId = int(round(u_FogParams.w));
    if (dimId != 0) return baseSky;

    float rain = u_Weather.x;
    float nightVis = (1.0 - u_SkyColor.w) * (1.0 - rain);

    // Crisp procedural stars at night
    if (nightVis > 0.02 && V.y > 0.0) {
        vec2 starGrid = floor(V.xz / (V.y + 0.35) * 260.0);
        float starHash = hash12(starGrid);
        if (starHash > 0.994) {
            float twinkle = 0.65 + 0.35 * sin(u_Time.x * 3.5 + starHash * 100.0);
            vec3 starTint = mix(vec3(0.75, 0.88, 1.0), vec3(1.0, 0.88, 0.72), fract(starHash * 37.0));
            baseSky += starTint * smoothstep(0.994, 0.9995, starHash) * twinkle * nightVis * smoothstep(0.0, 0.25, V.y) * 2.5;
        }
    }

    // Crisp Solar & Lunar disks
    float sunCos = dot(V, u_SunDirection.xyz);
    float sunDisk = smoothstep(0.9991, 0.9996, sunCos) * (1.0 - rain);
    baseSky += u_SunColor.rgb * sunDisk * 14.0;

    float moonCos = dot(V, u_MoonDirection.xyz);
    float moonDisk = smoothstep(0.9993, 0.9997, moonCos) * (1.0 - rain);
    baseSky += u_MoonColor.rgb * moonDisk * 6.0;

    // Composite fast sculpted clouds
    vec4 clouds = evaluateFastSculptedClouds(V);
    baseSky = mix(baseSky, clouds.rgb, clouds.a);

    return baseSky;
}

#endif
