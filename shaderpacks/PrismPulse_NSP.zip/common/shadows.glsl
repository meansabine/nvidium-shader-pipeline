#ifndef SHADOWS_GLSL
#define SHADOWS_GLSL

#include "scene_uniforms.glsl"
#include "options.glsl"

// 4-Tap Rotated Vogel Disk PCF: 2.25x faster than 9-tap PCF with indistinguishable softness under IGN jitter!
const vec2 VOGEL_4[4] = vec2[4](
    vec2( 0.353553,  0.000000),
    vec2(-0.433013,  0.499999),
    vec2( 0.088388, -0.785674),
    vec2( 0.530330,  0.765466)
);

float sampleShadowBilinear(sampler2DArray shadowMap, vec3 shadowCoord, float layer) {
    vec2 texSize = vec2(u_ShadowParams.x);
    vec2 invSize = vec2(u_ShadowParams.y);
    vec2 uv = shadowCoord.xy * texSize - 0.5;
    vec2 baseUV = (floor(uv) + 0.5) * invSize;
    vec2 f = fract(uv);

    float refZ = clamp(shadowCoord.z, 0.0, 1.0);
    float d00 = step(refZ, texture(shadowMap, vec3(baseUV, layer)).r);
    float d10 = step(refZ, texture(shadowMap, vec3(baseUV + vec2(invSize.x, 0.0), layer)).r);
    float d01 = step(refZ, texture(shadowMap, vec3(baseUV + vec2(0.0, invSize.y), layer)).r);
    float d11 = step(refZ, texture(shadowMap, vec3(baseUV + invSize, layer)).r);

    return mix(mix(d00, d10, f.x), mix(d01, d11, f.x), f.y);
}

float sampleSingleCascadePCF(sampler2DArray shadowMap, vec3 camRelPos, vec3 N, int cascadeIdx, float ignAngle) {
    float cascadeScale = (cascadeIdx == 0) ? 1.0 : ((cascadeIdx == 1) ? 2.2 : 4.8);
    float NoL = clamp(dot(N, u_ShadowLightDir.xyz), 0.0, 1.0);
    float normalBias = (0.025 + 0.045 * (1.0 - NoL)) * cascadeScale;

    vec3 biasedPos = camRelPos + N * normalBias;
    vec4 lightClip = getCascadeViewProj(cascadeIdx) * vec4(biasedPos, 1.0);
    vec3 shadowNDC = lightClip.xyz / max(lightClip.w, 1.0e-6);
    vec3 shadowCoord = shadowNDC * 0.5 + 0.5;

    if (any(lessThan(shadowCoord.xy, vec2(0.002))) || any(greaterThan(shadowCoord.xy, vec2(0.998))) || shadowCoord.z > 0.9999) {
        return 1.0;
    }

    float slopeBias = (0.00025 + 0.00055 * (1.0 - NoL)) * cascadeScale;
    shadowCoord.z -= slopeBias;

    float radius = u_ShadowParams.y * (1.6 * OPT_SHADOW_SOFTNESS) / sqrt(cascadeScale);
    float s = sin(ignAngle);
    float c = cos(ignAngle);
    mat2 rot = mat2(c, -s, s, c);

    float shadowSum = 0.0;
    float layer = float(cascadeIdx);
    for (int i = 0; i < 4; ++i) {
        vec2 offset = (rot * VOGEL_4[i]) * radius;
        shadowSum += sampleShadowBilinear(shadowMap, vec3(shadowCoord.xy + offset, shadowCoord.z), layer);
    }
    return shadowSum * 0.25;
}

float evaluateCascadedShadow(sampler2DArray shadowMap, vec3 camRelPos, vec3 N, vec2 pixelCoord) {
    float dist = length(camRelPos);
    if (dist >= u_CascadeSplits.w || u_ShadowLightDir.w <= 0.001) {
        return 1.0;
    }

    float ign = interleavedGradientNoise(pixelCoord, u_Time.z) * 6.2831853;
    int cascadeIdx = 2;
    if (dist < u_CascadeSplits.x) {
        cascadeIdx = 0;
    } else if (dist < u_CascadeSplits.y) {
        cascadeIdx = 1;
    }

    float shadow = sampleSingleCascadePCF(shadowMap, camRelPos, N, cascadeIdx, ign);

    // Smooth cascade transition only inside a narrow 10% overlap band
    if (cascadeIdx == 0 && dist > u_CascadeSplits.x * 0.90) {
        float blend = smoothstep(u_CascadeSplits.x * 0.90, u_CascadeSplits.x, dist);
        float nextShadow = sampleSingleCascadePCF(shadowMap, camRelPos, N, 1, ign);
        shadow = mix(shadow, nextShadow, blend);
    } else if (cascadeIdx == 1 && dist > u_CascadeSplits.y * 0.90) {
        float blend = smoothstep(u_CascadeSplits.y * 0.90, u_CascadeSplits.y, dist);
        float nextShadow = sampleSingleCascadePCF(shadowMap, camRelPos, N, 2, ign);
        shadow = mix(shadow, nextShadow, blend);
    }

    float distFade = 1.0 - smoothstep(u_CascadeSplits.w * 0.85, u_CascadeSplits.w, dist);
    return mix(1.0, shadow, distFade * u_ShadowLightDir.w);
}

// Single hardware tap for volumetric rays (ultra-fast)
float sampleVolumetricShadowTap(sampler2DArray shadowMap, vec3 camRelPos) {
    float dist = length(camRelPos);
    int cascadeIdx = (dist < u_CascadeSplits.x) ? 0 : ((dist < u_CascadeSplits.y) ? 1 : 2);
    vec4 lightClip = getCascadeViewProj(cascadeIdx) * vec4(camRelPos, 1.0);
    vec3 uvz = (lightClip.xyz / max(lightClip.w, 1.0e-6)) * 0.5 + 0.5;
    if (any(lessThan(uvz.xy, vec2(0.0))) || any(greaterThan(uvz.xy, vec2(1.0)))) return 1.0;
    float mapDepth = texture(shadowMap, vec3(uvz.xy, float(cascadeIdx))).r;
    return step(uvz.z - 0.0008, mapDepth);
}

#endif
